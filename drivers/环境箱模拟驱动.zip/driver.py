# -*- coding: utf-8 -*-
# 这个文件提供了一个设备驱动模板
import profile
import api
import time


class Information:
    # 设备类型代码
    dev_type = 'ec'
    # 生产商名称
    vendor = '李杰'
    # 支持的设备型号
    model = 'LJ-119'
    # 支持的版本
    version = 'V1.0'

    def __str__(self):
        return '<{}/{}/{}/{}>'.format(self.dev_type, self.vendor, self.model, self.vendor)


class Install:
    """驱动安装时调用"""
    def __init__(self):
        pass
        
    def install(self):
        print("执行环境箱模拟驱动安装程序")


class Uninstall:
    """驱动卸载时调用"""
    def __init__(self):
        pass

    def uninstall(self):
        print("执行环境箱模拟驱动卸载程序")


class Driver:
    """
    这个是驱动样板，驱动主题程序就按这个写
    """
    def __init__(self, model, conf, *args, **kwargs):
        self.model = model
        self.dev_type = self.model.type.code
        self.conf = conf

        now = time.time()
        self.startup_tsp = time.localtime(now)
        self.startup_datetime = time.strftime(profile.DT_FORMAT, self.startup_tsp)
        
    def get_driver_statement(self):
        now = time.time()

        return {
            'pid': os.getpid(),
            '工作目录': os.getcwd(),
            '启动时间': self.startup_datetime,
            '运行时间': now - self.startup_tsp,
            'vendor': self.model.vendor,
            'model': self.model.model,
            'version': self.model.version,
        }

    def run_until_exit(self, *args, **kwargs):
        print(profile.platform_root_dir)
        print("环境箱模拟驱动启动中！")
        
        while True:
            statement = self.get_driver_statement()
            api.device_set_profile(self.dev_type, statement)
            time.sleep(5)
